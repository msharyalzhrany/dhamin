// شعار ضامن: درع على شكل بيت (سقف مدبّب) + علامة صح = "الصفقة مضمونة"
// الألوان: الدرع أخضر #39AB79 والعلامة #041C16. الكتابة تأخذ لون النص الحالي.
import { cn } from '@/lib/utils';

export function LogoMark({ className, tile = false }: { className?: string; tile?: boolean }) {
  return (
    <svg viewBox="0 0 48 48" className={cn('size-9 shrink-0', className)} aria-hidden="true">
      {tile && <rect width="48" height="48" rx="12" fill="#041C16" />}
      <path d="M24 7 L38.5 17 V29 C38.5 35.2 32 39.6 24 42 C16 39.6 9.5 35.2 9.5 29 V17 Z" fill="#39AB79" />
      <path d="M16.8 25.2 L22 30.4 L31.4 19.8" fill="none" stroke="#041C16" strokeWidth="3.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo({ className, markClass, showText = true, stacked = false }: { className?: string; markClass?: string; showText?: boolean; stacked?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', stacked && 'flex-col gap-2', className)} aria-label="ضامن Dhamin">
      <LogoMark className={markClass} />
      {showText && (
        <span className={cn('flex flex-col leading-none', stacked && 'items-center')}>
          <span className="font-arabic text-[1.45em] font-bold tracking-normal" lang="ar" dir="rtl">ضامن</span>
          <span className="mt-0.5 text-[0.62em] font-semibold uppercase tracking-[0.32em] opacity-70" lang="en" dir="ltr">Dhamin</span>
        </span>
      )}
    </span>
  );
}
